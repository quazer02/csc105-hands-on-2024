const signup = () => {
    return <div>SignUpPage</div>;
}
export default signup;