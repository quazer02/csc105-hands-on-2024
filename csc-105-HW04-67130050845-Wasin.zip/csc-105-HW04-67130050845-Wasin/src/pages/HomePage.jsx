const HomePage = () => {
    return (
        <div>
            <h1>Welcome To The Home Page</h1>
        </div>
    )
}
export default HomePage;